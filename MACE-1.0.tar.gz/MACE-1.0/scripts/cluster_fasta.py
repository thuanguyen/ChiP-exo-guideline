#!/usr/bin/env python
'''---------------------------------------------------------------------------------------
Clustering DNA sequences
------------------------------------------------------------------------------------------'''
#import built-in modules
import os,sys
if sys.version_info[0] != 2 or sys.version_info[1] != 7:
        print >>sys.stderr, "\nYou are using python" + str(sys.version_info[0]) + '.' +\
        str(sys.version_info[1]) + " Apex needs python2.7!\n"
        sys.exit()
from optparse import OptionParser
import warnings
from pymix import mixture
from pymix import bioMixture

__author__ = "Liguo Wang"
__copyright__ = "Copyright 2011-2013, Liguo Wang. All rights reserved."
__credits__ = []
__license__ = "GPL"
__version__="1.0"
__maintainer__ = "Liguo Wang"
__email__ = "wang.liguo@mayo.edu"
__status__ = "Production"


def check_fasta(f):
	'''check fasta file. If all sequences are the same length, return length, else return 0'''
	seq_len=set()
	flag=False
	for line in open(f,'r'):
		line=line.strip()
		if line.startswith(('#',' ','>')):
			flag=True
			continue
		tmp = len(line)
		seq_len.add(tmp)
	if not flag:
		return 0
	if len(seq_len) != 1:
		return 0
	if tmp > 0:
		return tmp
	else:
		return 0
		 

def main():
	usage="%prog [options]"
	parser = OptionParser(usage,version="%prog " + __version__)
	parser.add_option("-f","--input-file",action="store",type="string",dest="input_file",help="Input sequence file in FASTA format. All sequences must be the same length.")
	parser.add_option("-k","--cluster",action="store",type="int",dest="cluster_num", help="Number of components in mixture model.")
	parser.add_option("-o","--out-prefix",action="store",type="string",dest="output_prefix",help="Prefix of output files (sub clusters, still in FASTA format).")
	parser.add_option("-d","--delta",action="store",type="float",dest="delta",default=0.01,help="Minimim difference in log-likelihood before convergence. default=%default")
	parser.add_option("-m","--max-steps",action="store",type="int",dest="max_steps",default=1000,help="Maximum number of steps in each run. default=%default")

	(options,args)=parser.parse_args()
	if not (options.input_file and options.cluster_num and options.output_prefix):
		parser.print_help()
		sys.exit(0)
	print >>sys.stderr, "checking input fasta ..."
	seq_length = check_fasta(options.input_file)
	
	if seq_length == 0:
		print >>sys.stderr, "Not FASTA format"
		sys.exit(0)	
	
	fdata = bioMixture.readFastaSequences(options.input_file)
	m = bioMixture.getModel(options.cluster_num,seq_length)
	m.randMaxEM(data = fdata, nr_runs = seq_length, nr_steps = options.max_steps, delta = options.delta)
	fdata.writeClusteringFasta(fn_pref = options.output_prefix, m = m)
	
								
if __name__ == '__main__':
	main()
