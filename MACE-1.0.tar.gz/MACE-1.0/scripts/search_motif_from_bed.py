#!/usr/bin/env python
'''searhing motif represented by IUPAC'''

#import built-in modules
import os,sys
import re
import string
from optparse import OptionParser
import warnings
import string
import collections
import math
import sets
import numpy
import operator
try:
	import motility
except:
	print >>sys.stderr, "Error: Cannot find \'motility\' module. Download and install 'motility' from \'http://cartwheel.caltech.edu/motility/\'"

#import third-party modules


#built in modules
import motility
from exomodule import fasta
from exomodule import cigar
from exomodule import BED
from exomodule import motif
from bx.bbi.bigwig_file import BigWigFile

#changes to the paths

__author__ = "Liguo Wang"
__copyright__ = ""
__credits__ = []
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Liguo Wang"
__email__ = "wang.liguo@mayo.edu"
__status__ = "Development" #Prototype or Production


def motif_score(chrom,start,end,bw_obj):
	'''retrieve signal from bigwig file based on genome coordinates'''
	try:
		bw_signal.extend(bw.get_as_array(chrom,start,end))
		bw_signal = nan_to_num(bw_signal)
		return mean(bw_signal)
	except:
		return 0.0

def rank_motif_by_position(m_bed,motifs):
	'''pick motif that most close to bed center'''
	dist={}
	for motif in motifs:
		(chr,st,end,strand,seq) = motif.split(':')
		st = int(st)
		end = int(end)
		mid_motif = int(st + (end-st)/2)
		dist[motif] = abs(mid_motif - m_bed)
	a = sorted(dist.iteritems(), key=operator.itemgetter(1))
	return a[0][0]

def rank_motif_by_score(m_bed,motifs,bw):
	'''pick motif that most conserved'''
	dist={}
	for motif in motifs:
		(chr,st,end,strand,seq) = motif.split(':')
		st = int(st)
		end = int(end)
		score = motif_score(chr,st,end,bw)
		dist[motif] = score
	a = sorted(dist.iteritems(), key=operator.itemgetter(1),reverse=True)
	return a[0][0]


def main():
	usage="%prog [options]"
	parser = OptionParser(usage,version="%prog " + __version__)
	parser.add_option("-b","--bed",action="store",type="string",dest="bed_file",help="bed format file")
	parser.add_option("-r","--reference",action="store",type="string",dest="fasta_file",help="reference sequece in fasta format")
	parser.add_option("-s","--sstrand",action="store",type="string",dest="seq_strand",help="search motif on '+' or '-' or '+-' strand. Only take '+', '-' or '+-'.")
	parser.add_option("-c","--cons",action="store",type="string",dest="bw_file",help="Conservation score in BigWig format. Optional")
	parser.add_option("-m","--motif",action="store",type="string",dest="motif_iupac",help="Motif i IUPAC format. For example, CTCF motif is represented as \"RSYDMCMYCTRSTGK\"")
	parser.add_option("-o","--out-prefix",action="store",type="string",dest="output",help="Output file")
	parser.add_option("-n","--mismatch",action="store",type="int",dest="mismatch_num",default=0, help="Number of mismaatch. default=%default")
	parser.add_option("-x","--max-motif",action="store",type="int",dest="maximum_motif",default=100, help="maximum number of motif per sequence. default=%default")
	(options,args)=parser.parse_args()

	if not (options.bed_file and options.output and options.motif_iupac and options.fasta_file):
		parser.print_help()
		sys.exit(0)
	
	fa_obj = fasta.Fasta(options.fasta_file)
	if options.bw_file:
		bw_obj = BigWigFile( file=open(options.bw_file ) )
	FOUT1 = open(options.output + 'motif_list.xls','w')
	
	for line in open(options.bed_file,'r'):
		line=line.strip()
		fields=line.split()
		chrom = fields[0]
		st = int(fields[1])
		end = int(fields[2])
		mid_bed = int(st + (end-st)/2)
		motifs = fa_obj.search_motif_iupac(chrom, st, end, options.motif_iupac,options.mismatch_num,options.maximum_motif)
		#dists = fa_obj.cal_motif_dist(chrom, st, end, options.motif_iupac,options.mismatch_num,options.maximum_motif)
		fmotifs=[]	#motifs filtered by strand
		for motif in motifs:
			(chr,st,end,strand,seq) = motif.split(':')
			if strand not in options.seq_strand:
				continue
			fmotifs.append(motif)
		
		if len(fmotifs) >0:
			if options.bw_file:
				tmp = rank_motif_by_score(mid_bed, fmotifs,bw_obj)
			else:
				tmp =rank_motif_by_position(mid_bed, fmotifs)
			print >>FOUT1, line + '\t' + tmp
		else:
			print >>FOUT1, line + '\tNA'
												
if __name__ == '__main__':
	main()
