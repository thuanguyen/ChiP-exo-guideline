#!/usr/bin/env python

#import built-in modules
import os,sys
import re
import string
from optparse import OptionParser
import warnings
import string
import collections
from numpy import sum,mean,median,std,isnan,nan_to_num

#import third-party modules
from bx.bitset import *
from bx.bitset_builders import *
from bx.intervals import *
from bx.bbi.bigwig_file import BigWigFile

#import my own modules
from qcmodule import SAM
from qcmodule import fickett
from qcmodule import BED
from qcmodule import wiggle
from qcmodule import fasta
from qcmodule import orf
from qcmodule import quantile
#changing history to this module
__author__ = "Liguo Wang"
__copyright__ = "Copyright 2012. All rights reserved."
__credits__ = []
__license__ = "GPL"
__version__="1.0"
__maintainer__ = "Liguo Wang"
__email__ = "wang.liguo@mayo.edu"
__status__ = "Production"

def summay_bwfile(inbed,bwfile,rm_gap):
	'''retrieve signal from bigwig file for each entry in input bed file. return mean, median, std'''
	bw = BigWigFile( file=open( bwfile ) )
	
	for line in open(inbed):
		bw_signal=[]
		try:
			if line.startswith('#'):continue
			if line.startswith('track'):continue
			if line.startswith('browser'):continue
			if not line.strip():
				continue
			else:
				line = line.rstrip('\r\n')
				fields = line.split()
				chrom = fields[0]
				start = int(fields[1])
				end = int(fields[2])
		except:
			print >>sys.stderr,"Must be  chrom [space] start [space] end: " + line,
			continue		
		bw_signals = bw.get_as_array(chrom,start,end)
		if rm_gap is True:
			bw_signal = nan_to_num(bw_signals)
		else:
			for i in bw_signals:
				if isnan(i):
					continue
				if i == 0:
					continue
				bw_signal.append(i)
		#print chrom +'\t'+ str(start) +'\t'+ str(end) + '\t' + str(sum(bw_signal)) +'\t'+ str(mean(bw_signal)) + '\t' +  str(median(bw_signal)) + '\t' +  str(std(bw_signal)) + str(bw_signal)
		print chrom +'\t'+ str(start) +'\t'+ str(end) + '\t' + str(sum(bw_signal)) +'\t'+ str(mean(bw_signal)) + '\t' +  str(median(bw_signal)) + '\t' +  str(std(bw_signal))
		
def main():
	usage="%prog [options]"
	parser = OptionParser(usage,version="%prog " + __version__)
	parser.add_option("-i","--input-file",action="store",type="string",dest="bw_file",help="BigWig format file")
	parser.add_option("-b","--bed-file",action="store",type="string",dest="bed_file",help="Bed format file. Chrom <tab> start <tab> end")
	parser.add_option("-g","--keep-gap",action="store_true",dest="gap_keep",help="Presense of this option tells progam to keep gaps (coverage signal over gaps will be 0) before calculating mean, median and std. Otherwise gaps will be removed")  
	(options,args)=parser.parse_args()
	if not (options.bw_file and options.bed_file):
		parser.print_help()
		print >>sys.stderr, "\n4 additional columns (sum, mean, median, std) will be appended to bed entries\n"
		sys.exit(0)
    
	summay_bwfile(options.bed_file,options.bw_file,options.gap_keep)
	
if __name__ == '__main__':
	main()
