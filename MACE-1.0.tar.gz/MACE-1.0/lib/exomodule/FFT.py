import numpy
from numpy.fft import rfft, irfft
''' Use Fast Fourier Transform (FFT) to calculate cross correlation. '''
def crfft(lst1,lst2):
	lst1_l = len(lst1)
	lst2_l = len(lst2)
	if lst1_l != lst2_l:
		return None
	if lst1_l == 0 or lst2_l == 0:
		return None
	x = rfft(lst1)
	y = rfft(lst2[::-1])
	cr_array = irfft(x*y)
	tmp = lst1_l - numpy.argmax(cr_array)
	if tmp == lst1_l:
		return None
	else:
		return tmp
