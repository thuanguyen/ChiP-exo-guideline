# pysam versioning information

__version__ = "0.6"

__samtools_version__ = "0.1.18"

__tabix_version__ = "0.2.5"
