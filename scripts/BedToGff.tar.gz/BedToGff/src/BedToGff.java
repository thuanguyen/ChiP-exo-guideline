import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BedToGff 
{
	public static void main( String[] strArgA ) 
	{
		String			strBed			= strArgA[ 0 ];
		String			strGff			= strArgA[ 1 ];
		
		ConvertBedToGff( strBed, strGff );
	}
	
	private static void ConvertBedToGff( String strBed, String strGff )
	{
		System.out.println( String.format( "# bed file: %s", strBed ) );
		System.out.println( String.format( "# gff file: %s", strGff ) );
		
		try
		{
			BufferedReader	br				= new BufferedReader( new FileReader( strBed ) );
			BufferedWriter	bw				= new BufferedWriter( new FileWriter( strGff ) );

			String			strLine			= null;

			while( true )
			{
				strLine = br.readLine();			

				if( strLine == null )
					break;

				String[]		strA			= strLine.split( "\t" );
				
				String			strChro			= "NC_000913";
				String			strFeature		= strGff.substring( 0, strGff.lastIndexOf( "." ) );
				String			strStart		= strA[ 1 ];
				String			strEnd			= strA[ 2 ];
				String			strId			= null;
				String			strScore		= "1";
				
				if( strA.length > 3 )			strId			= strA[ 3 ];
				if( strA.length > 4 )			strScore		= strA[ 4 ];
				
				double			dScore			= Double.parseDouble( strScore );
				dScore			= 1 / dScore;
				
				String			strAttr			= strId != null ? String.format( "ID=%s;", strId ) : "";
				
				String			str				= String.format( "%s\t%s\t%s\t%s\t%s\t%f\t%s\t%s\t%s",
						strChro, "MACE", strFeature, strStart, strEnd, dScore, "+", ".", strAttr );
				
				bw.write( str + "\r\n" );
				bw.flush();				
			}

			br.close();
			bw.close();	
		}
		catch( FileNotFoundException e )
		{
			e.printStackTrace();
		}
		catch( IOException e )
		{
			e.printStackTrace();
		}
	}
}
