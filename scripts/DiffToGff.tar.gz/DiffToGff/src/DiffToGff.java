
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class DiffToGff 
{
	public static void main( String[] strArgA ) 
	{
		if( strArgA.length != 5 )
		{
			PrintUsage();
			System.exit( 0 );
		}
		
		String			strDiff			= strArgA[ 0 ];
		String			strAnno			= strArgA[ 1 ];
		String			strQvalue		= strArgA[ 2 ];
		String			strThresh		= strArgA[ 3 ];
		String			strGff			= strArgA[ 4 ];
		
		double			dQvalue			= Double.parseDouble(( strQvalue ));
		double			dThresh			= Double.parseDouble( strThresh );		
		
		MakeGffFromDiff( strDiff, strAnno, dQvalue, dThresh, strGff );
	}
	
	private static void MakeGffFromDiff( String strDiff, String strAnno, double dQvalue, double dThresh, String strGff )
	{		
		HashMap< String, ArrayList >		hsDiff			= new HashMap<>();
		HashMap< String, ArrayList >		hsAnno			= new HashMap<>();
		
		ReadDiff( strDiff, hsDiff );
		ReadGff( strAnno, hsAnno );
		
		try
		{
			BufferedWriter	bw				= new BufferedWriter( new FileWriter( strGff ) );
		
			for( String strGene : hsDiff.keySet() )
			{
				ArrayList		alDiff			= hsDiff.get( strGene );
				ArrayList		alAnno			= hsAnno.get( strGene );

				String			strStart		= ( String ) alAnno.get( 1 );
				String			strEnd			= ( String ) alAnno.get( 2 );
				String			strStrand		= ( String ) alAnno.get( 3 );

				String			strStatus		= ( String ) alDiff.get( 1 );
				String			strValue1		= ( String ) alDiff.get( 2 );
				String			strValue2		= ( String ) alDiff.get( 3 );
				String			strFold			= ( String ) alDiff.get( 4 );
				String			strPvalue		= ( String ) alDiff.get( 5 );
				String			strQvalue		= ( String ) alDiff.get( 6 );
				String			strSignificant	= ( String ) alDiff.get( 7 );

				double			dFold			= Double.parseDouble( strFold );
				double			dPvalue0		= Double.parseDouble( strPvalue );
				double			dQvalue0		= Double.parseDouble( strQvalue );

				if( strStatus.equals( "OK" ) == false )
					continue;

				if( strSignificant.equals( "yes" ) == false )
					continue;

				//if( dPvalue0 > dPvalue )
				//	continue;
				if( dQvalue0 > dQvalue )
					continue;
				
				if( Math.abs( dFold ) < dThresh )
					continue;

				String			strAttr			= String.format( "log2fold=%s;value1=%s;value2=%s;",
						strFold, strValue1, strValue2 );

				String			str				= String.format( "%s\t%s\t%s\t%s\t%s\t%.2f\t%s\t%s\t%s\r\n",
						"NC_000913", "cuffdiff", "cuffdiff_" + strGff + "_" + strStrand, 
						strStart, strEnd, dFold, ".", ".", strAttr );

				bw.write( str );
			}
			
			bw.close();
		}
		catch( FileNotFoundException e )
		{
			e.printStackTrace();			
		}
		catch( IOException e )
		{
			e.printStackTrace();			
		}		
	}
	
	private static void ReadGff( String strAnno, HashMap< String, ArrayList > hs )
	{
		try
		{
			String			strLine			= null;			
			BufferedReader	br				= new BufferedReader( new FileReader( strAnno ) );

			while( true )
			{
				strLine = br.readLine();			

				if( strLine == null )
					break;

				String[]		strA			= strLine.split( "\t" );
				
				if( strA.length < 4 )			continue;
				
				String			strAttr			= strA[ 8 ];
				String[]		strAttrA		= strAttr.split( ";" );
				String			strGene			= strAttrA[ 0 ].substring( strAttrA[ 0 ].indexOf( "=" ) + 1 );
				String			strStart		= strA[ 3 ];
				String			strEnd			= strA[ 4 ];
				String			strStrand		= strA[ 6 ];				
				
				ArrayList		al				= new ArrayList();
				
				al.add( strGene );
				al.add( strStart );
				al.add( strEnd );
				al.add( strStrand );				
				
				hs.put( strGene, al );
			}
			
			br.close();
		}
		catch( FileNotFoundException e )
		{
			e.printStackTrace();			
		}
		catch( IOException e )
		{
			e.printStackTrace();			
		}
		
		System.out.println( String.format( "# %d entries from .gff file", hs.size() ) );
	}
	
	private static void ReadDiff( String strDiff, HashMap< String, ArrayList > hs )
	{
		try
		{
			String			strLine			= null;			
			BufferedReader	br				= new BufferedReader( new FileReader( strDiff ) );

			while( true )
			{
				strLine = br.readLine();			

				if( strLine == null )
					break;

				String[]		strA			= strLine.split( "\t" );
				
				if( strA[ 0 ].equals( "test_id" ) == true  )
					continue;
				
				if( strA[ 0 ].equals( "=" ) == true )
					continue;
				
				String			strGene			= strA[ 0 ].substring( 1 );
				String			strStatus		= strA[ 6 ];
				String			strValue1		= strA[ 7 ];
				String			strValue2		= strA[ 8 ];
				String			strFold			= strA[ 9 ];
				String			strPvalue		= strA[ 11 ];
				String			strQvalue		= strA[ 12 ];
				String			strSigfinicant	= strA[ 13 ];
				
				ArrayList		al				= new ArrayList();
				
				al.add( strGene );
				al.add( strStatus );
				al.add( strValue1 );
				al.add( strValue2 );
				al.add( strFold );
				al.add( strPvalue );
				al.add( strQvalue );
				al.add( strSigfinicant );
				
				hs.put( strGene, al );
			}
			
			br.close();
		}
		catch( FileNotFoundException e )
		{
			e.printStackTrace();			
		}
		catch( IOException e )
		{
			e.printStackTrace();			
		}
		
		System.out.println( String.format( "# %d entries from .diff file", hs.size() ) );
	}
	
	private static void PrintUsage()
	{
		System.out.println( "java DiffToGff file1.diff annotation.gff qvalue foldchage file2.gff" );
	}
}
